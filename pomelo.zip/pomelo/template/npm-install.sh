cd ./game-server && npm install -d
echo '============   game-server npm installed ============'
cd ..
cd ./web-server && npm install -d
echo '============   web-server npm installed ============'
